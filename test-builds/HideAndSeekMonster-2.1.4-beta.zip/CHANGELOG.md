# Changelog

## 2.1.4 (beta)
- The monster can't attack while it holds something with its grab beam – and a click on something grabbable
  (item, door, cart …) only grabs, it doesn't attack too.

## 2.1.3 (beta)
- Scores, item owners and the after-round are reset when a new lobby starts (lobby restarted, another lobby joined,
  back to the main menu). Map changes inside the same lobby keep them.

## 2.1.2 (beta)
- **Third-person view for hiders:** press **V** during a round to switch between first and third person – your own
  robot is visible in third person.

## 2.1.1 (beta)
- Fix: a hider who gets revived during the hunt (defibrillator …) counts as alive again for the score – they can
  still survive (or die again later).
- Fix: used-up consumables (health packs, upgrades …) came back at the next round. The host now remembers on which
  map each item was last seen: gone on the same map = used up, stays gone; left on an older map = comes back.
- Fix: game enemies spawned after the round – they stay off while everyone looks at the hiding spots, votes and
  waits for the next round.

## 2.1.0

### New round flow
- **Item time at round start** (60 s): everyone stands still and picks their free item with **I** – the hiding time
  only starts afterwards. It ends early when everyone is done (taking your item counts, **J** = done / skip).
- **After the round:** everyone is revived and healed where they are and gets **60 s to look at the hiding spots** –
  all hiders of the round stay marked (through walls) and the monster keeps its form. **J** votes to skip (majority).
- Then everyone goes into the truck for a **15 s vote** (next monster + map), and the **next round starts by itself**
  – after a voted map has fully loaded.
- At every round start everyone is healed to full health and all battery items are recharged.
- Leaving the level (lobby restart, main menu) cancels everything of the after-round.
- The end of a round and the scores are sent exactly once.

### Items
- The item picker follows Flyguy's **item gallery**: hiders get their items (tranq, pulse pistol, stun / pulse
  grenade, pulse mine, leaf blower) plus the shared ones; the monster may now pick an item too – every item except
  guns, melee weapons and the defibrillator; the classic hunter gets every item except the defibrillator.
- Weapons don't run out of energy during a round – for everyone (hider pistols still have 2 shots per round).
- Unused owned items (health packs, upgrades …) left behind on the old map come back to their owner; used-up ones
  stay gone.

### Monsters & animations
- **New animation system:** the monsters play their own clips directly – idle, walk, run, jump, fall, attack,
  special and a loop while charging / sprinting.
  - Robe, Headgrab, Reaper, Chef, Gnome, Banger, Clown, Huntsman, Trudge, Rugrat, Cleanup Crew, Mentalist, Bowtie,
    Gambit, Upscream, Birthday Boy and Apex Predator got fitting animations for their attacks and specials.
  - Elsa stays in her big form with a calm standing pose; Animal no longer faces backwards.
  - Monsters animated by the game's code got procedural animations: the Pony gallops, Spewer, Heart Hugger and Oogly
    move, Bella's tricycle wheels turn and the girl only shows herself while attacking or sprinting.
  - Headman goes back to its normal face after every action and bites with its own chomp.
- **Animation tuner** (F7 → Animations): pick, cut, speed up and preview the clip of every action and save it.
- The monster player's robot casts no shadow any more.
- The monster can't attack, scan or use its special while it is knocked over / stunned.
- Charge follows slopes and climbs stairs instead of launching the monster into the air.
- Clown laser: 50 damage per hit.

### Fixes
- Monster keys work again with game version v0.5.2 (the game switched the mod's key bindings off).
- Markers (hiders, scan) sit at the right height when the game window isn't 16:9.
- Menus: no left / right scrollbars, texts wrap or shrink instead of being cut off.
- New How To Play pages (end of the round, points) and new credits.

## 2.0.0 – R.E.P.O. Hide 'n Seek

The mod has a new look and name: **R.E.P.O. Hide 'n Seek** – now with two game modes, new specials, item rules,
a drawn How To Play and a Monster Showcase. (The Thunderstore package stays `HideAndSeekMonster`, so updates keep
working.)

### Two game modes
- **Monster mode:** the hunter becomes a real monster of the game, each with its own special.
- **Classic mode** (new, F8 menu): the hunter stays a player and picks a **start weapon** (melee or gun) plus a
  second item while the others hide (I key). Melee weapons never break; the hunter's weapons have unlimited energy.

### Rules from the How To Play
- **Scoring:** 1st hider to die = 0 points, 2nd = 1, 3rd = 2 …, survivors get as many points as there were hiders.
  The hunter gets a point for **every** hider that dies, whatever killed them.
- **The monster can die** (not invincible by default) – then the hiders win.
- **Monster mode – weapons banned:** guns, melee weapons and cart cannons can't be grabbed (toggle in the F8 menu).
- **Free item each round:** every hider presses **I** while hiding and picks one item from a picker with icons and
  categories – only items hiders may use (no guns / melee / cart cannons / scouts / explosives).
- **Hider weapons:** tranq and pulse pistol have **2 shots per round** and can't be recharged.
- **Classic – hiders:** can't grab melee weapons, may wrestle guns but only fire the tranq / pulse pistol, can't put
  the hunter's weapons into their inventory.
- **Item ownership:** items the mod hands out go back to their owner next round (weapons and explosives even when
  used up); weapons owned by a hider stay locked in the truck for that round.

### New and changed specials
- **Bowtie – Tornado:** sucks in items, weapons and players, whirls them around and flings everything away.
- **Snatcher – Lasso Grab:** lasso in the camera direction, reels a hider in for 5 s.
- **Birthday Boy – Balloon Mines:** up to 5 hovering balloon mines (40 damage); the oldest is moved while popped ones
  recharge (40 s).
- **Tick – Tumble-Bash:** roll around for up to 5 s (steer with the camera, jump, press again to stop), soft wall
  bounces, rolls under tables; hits knock hiders over (15 damage).
- **Upscream – Launch**, **Trudge – Impulse**, **Rugrat – Item Throw** (held items no longer push the Rugrat).
- **Swarm:** the real Gnomes / Bangers chase hiders they can see and hurt on contact; a Gambit roll summons real
  Gnomes too.
- **Zero-G Grab** floats caught hiders (8 s); **Gambit** only rolls the specials monsters currently have.
- **New cooldowns** for all specials (see the table in the README); Laser 50 damage per second; Charge / Lunge 50
  damage; Noxious Gas slows in 5 s blocks.

### Menus
- **How To Play** (18 drawn pages) and **Monster Showcase** (every special with a drawn animation, cooldown and
  monsters) in the F8 menu – art by Flyguy.
- **Debug menu (F7, host only):** revive / heal, teleport everyone (also knocked-over players), skip hiding, end the
  round, reset cooldowns, spawn real enemies, valuables, shop items and dummies.

### Fixes
- Everyone always sees the same monster (the host decides the pick).
- Balloon mines hang in the same place for everyone; the mouse cursor shows in all menus; no "ROAR!" text on the
  player scan; no red screen flash for hiders.

### Credits
Art and animation: **Flyguy** · Programming: **Napguin** · Ideas & playtesting: Looley18, MadKitKat, SongoCat

## 1.5.20

### After the round – revive, truck & vote (GitHub issue #4)
Requested in [issue #4](https://github.com/Napguin/REPO-Monster-Hide-and-Seek/issues/4): dead players should come
back between rounds. Now, when a round ends:
- Surviving hiders are **shown to everyone** for 6 s, so you see where they were hiding.
- **Every dead player is revived and healed**, and everyone is **teleported back into the truck**.
- A **vote** follows: volunteer to be the next monster (a random volunteer gets it), and vote to stay on this map
  or switch to one of 3 other maps.
- Can be turned off in the F8 menu (`Round / AfterRound`).

### New and reworked specials
- **Bowtie – Tornado:** a small tornado wanders forward for 7 s, sucks in items and valuables, whirls them around
  and flings everything away at the end – flying items hurt hiders. Hiders nearby are pulled in a little.
- **Upscream – Launch:** the closest hider (6 m) tumbles and is launched where the monster looks (25 damage).
- **Trudge – Impulse:** hiders within 9 m tumble, get sucked towards the Trudge, then a shockwave blasts them away
  (40 damage).
- **Rugrat – Item Throw:** grab a nearby valuable, use again to throw it really fast – real physics, 20–90 damage
  depending on speed and weight.
- **Heart Hugger – Noxious Gas:** 5 gas clouds that drift out and linger for 10 s; hiders inside are tranquilized
  (very slow, sluggish camera).
- **Gnome & Banger are playable – Swarm:** summons 5 of the game's real Gnomes / Bangers that hunt hiders on their own
  for 30 s (they have to spot them first and ignore the monster).
- **Robe & Headgrab – Charge:** short wind-up, then a fast horizontal dash (~14 m), 60 damage on contact.
  WASD is locked during the charge and it always goes the full distance.
- **Headman & Chef – Lunge:** like Charge, but in the camera direction (also up/down and in the air).
- **Elsa & Bella** now have Rapid Charge.
- **Flying Grab / Zero-G Grab:** caught hiders now tumble and can't get up, so the monster can grab and carry them.
  Flying Grab lasts 8 s.
- **Gambit** can roll every special in the mod – new specials are added automatically.
- Clown laser: 50 damage per tick. Radar Ping shows hiders for 2 s.

### Maps & menu
- F8 menu: **map size (level 1–20)** and a **Load new map** button – higher level = bigger map and higher moon phase.
- F8 menu: **hide / hunt time recommendation by moon phase** (maps get bigger every phase), applied with one click.

### Fixes & polish
- The monster can't open the map (Tab) during a round.
- Flying monsters use your own jump / crouch keys, stop below the ceiling, and the third-person camera no longer
  looks through ceilings or walls.

### Coming soon
More monsters are being worked on, plus a **How to Play** with hand-drawn animations. More features are on the way!

## 1.5.0
- **Damage instead of instant kills:** the main attack does 40 damage (players have 100 HP, config `AttackDamage`).
  Running into hiders no longer kills them. Specials do damage too: Laser 25 / 0.5 s, Shot 60, Leap 40, Throw 40.
- **Player Scan** (roar): shows how many players are within 15 m instead of the direction. Cooldown 20 s (`ScanCooldown`).
- **Radar Ping** (was X-ray): shows position and distance of every hider within 30 m for 1 s, 2 min cooldown. Every hider gets told
  whether they were detected or not.
- **Rapid Charge** (was Sprint): 5 s at 1.5x speed, 20 damage every 0.5 s to hiders close by, no main attack meanwhile.
- Test mode: no cooldowns.
- **Oogly: Flying Grab** – invisible stun bubble around it, and it can always fly. **Mentalist: Zero-G Grab** – stun bubble
  with zero gravity. **Spewer** can always fly too (space up, ctrl down).
- Cleanup Crew's head bounces off walls and explodes after 4 s (blinking faster and faster).
- Clown can't move while charging / firing the laser.
- Clown laser stays on the crosshair (jumping no longer knocks it off for the rest of the round).
- Oogly model tilted 45° more upright.
- Monster sounds no longer stack and play at most 2.5 s (Spewer's long puke sound).
- **Specials closer to the game:** Cleanup Crew throws its head (bomb + uranium cloud), Spewer pukes,
  Mentalist levitates and slams, Trudge ground-slams, Heart Hugger pulls hiders in with gas,
  Bowtie's scream pushes hiders away, Gambit rolls a random special.
- Apex Predator shows its attack form during Flying Charge. Rapid / Flying Charge have a visible aura.
- Fix: monster chosen during the hiding phase (e.g. Reaper, Elsa) was invisible / in the wrong form – hiding the own body
  no longer resets the monster's animation.
- Third-person camera no longer goes through the ceiling with tall monsters.
- Apex Predator: the monster-form meshes are shown during Flying Charge (and the duck grows).
- Softer effects: weaker colours, no flickering stun overlay, no spheres/sparks drawn around the camera
  (tight rooms, first person), charge aura is a ring on the floor.
- Big scan / radar waves are rings on the floor now (no more tinted screen). Oogly: stray trail parts hidden.
- **Flying Charge** (new, Apex Predator): fly for 6 s (space up, ctrl down), 10 damage every 0.5 s to hiders close by.

## 1.4.0
- **Every monster has a special ability** (middle mouse / F):
  Laser, Shot, Sprint, Leap attack, X-ray vision, Throw, Shockwave – see the README for who has what.
- Specials are visible everywhere: monster cards in both menus, ability bar with cooldowns for the monster,
  hiders see the monster's special while hiding and get a warning when it is used.
- **Echo roar:** roaring now shows the monster arrows towards every hider within 15 m for 1.5 s
  (direction only, no distance). Hiders it finds get an "Echoed!" warning.
- Monster models: animators are pushed into a visible state (big form, spawned, not despawning/stunned)
  and the model is re-grounded after transforming – fixes Elsa and similar two-form monsters.
- New full-screen **start menu (F8)**: seeker, monster and rules side by side, scores, big start button.

## 1.3.1
- New full-screen **monster selection**: card grid, details with the monster's abilities, countdown bar,
  "Random monster" button, keyboard control (arrows/WASD, Enter), reopen with **C** during the hiding phase.
- If the monster dies, the round now ends and the hiders win (scores are counted).
- "Monster invincible" now blocks every way the game can hurt or kill a player, not just one.
- Multiplayer: kills (touch, attack, laser) use the real network position of other players and
  horizontal distance – abilities should now hit other players, not only test dummies.
- More robust check that monster actions really come from the monster's player.
- Log shows distances for every attack (helps with tuning).

## 1.3.0
- **Score system** (totals over all rounds, shown after every round and in the F8 menu; host can reset):
  - Monster: 1 point per hider eaten.
  - Hiders: whoever lasts longest gets as many points as there were hiders, the next one 1 less, …,
    the first one eliminated gets 0. Everyone alive at the end gets the full points. Aborted rounds don't count.
- **Seeker picks their own monster** during the hiding phase (can be switched off in the F8 menu).
- **Clown laser:** laser monsters fire the game's real laser with the middle mouse button or **F**
  (3 s, 12 s cooldown). Everything the beam touches dies; walls and objects block it.
- **Monster can open doors again:** grabbing is allowed (doors, buttons, carts are grabbed in R.E.P.O.).
  Can be switched off with `Seeker / CanGrab`.

## 1.2.3
- Fix for R.E.P.O. v0.5.0: `PlayerController.OverrideSpeed` changed, which crashed the whole monster control
  every frame (no camera, attack, roar, speed or stamina). Game methods that can change between versions are
  now called version-tolerantly, and every monster feature runs separately.
- Harmony patches are applied one by one; a missing target only disables that one feature.
- Monster models are stripped in dependency order: no more "Can't remove … depends on it" errors in the log.

## 1.2.2
- Third-person camera now hooks into R.E.P.O.'s own camera render step (CameraUpdate) in addition to the render callbacks.
- Camera distance and height adapt to the size of the monster.
- Safety: if the third-person camera doesn't work, your own monster body is hidden so it never blocks your view.
- Roar plays through the game's own sound system; falls back to a generated growl if a monster has no sounds.
- Roar also on **R**, and shows a "ROAR!" banner.
- Test overlay shows camera status and the last played sound.

## 1.2.1
- Fix: third-person camera did nothing (R.E.P.O.'s camera is not Unity's `Camera.main`).
- Fix: monster controls were blocked by a wrong chat check.
- Fix: test keys (F9/F10/F11) now work independently of the monster controls.
- Seeker position for kills/dummies now taken from the player controller.
- One failing part no longer stops the rest of the mod; errors are shown in the test overlay and the log.
- More diagnostics in the test overlay and the log.

## 1.2.0
- **Test mode** for solo testing: start a round alone, you become the monster and training dummies act as hiders.
- Attack and touch kills work on the dummies; the overlay shows hit/miss with distance and angle.
- Test keys: F9 next monster (Shift+F9 previous), F10 spawn a dummy in front of you, F11 toggle overlay.
- Debug overlay and detailed log for each monster model (renderers, size, sounds, animator).

## 1.1.0
- The seeker now **is** a real R.E.P.O. monster: the model is taken from the game's enemies (choose one or random).
- Third-person camera for the monster so you see your own monster body (toggle with V).
- Monster abilities: **Attack** (left mouse, lunge + kill in front of you) and **Roar** (right mouse, plays the monster's sound, hiders nearby see a red flash).
- Monster sounds come from the original enemy.
- Monster can't grab objects.
- New settings: attack range, cooldowns, camera distance, key bindings.

## 1.0.0
- Initial release: Hide & Seek game mode with monster seeker.
