# Changelog

## 1.5.18 (beta)
- Upscream Launch: the push is now applied every frame while the ragdoll can move (like the Trudge pull) and always
  goes a bit upwards. More `[Launch]` log lines.

## 1.5.17 (beta)
- Upscream Launch fixed: the hider now really flies – the push waits until the ragdoll has started and is applied
  over a few frames (before, the ragdoll starting a moment later swallowed it). Range 6 m (was 4.5 m).

## 1.5.16 (beta)
- **Bowtie: Tornado** – a small tornado wanders forward for 7 s, sucks in items and valuables (up to 10) and whirls
  them around, then flings everything away. Flung items hurt hiders like Item Throw. Hiders nearby are pulled in a
  little and slowed, but not trapped.
- **Upscream: Launch** – the closest hider within 6 m tumbles and is launched where the monster looks (25 damage).
- **Trudge: Impulse** – hiders within 9 m tumble and are sucked towards the Trudge for 1.2 s, then a shockwave blasts
  them away (40 damage).
- **Elsa (dog) and Bella (tricycle)** now have Rapid Charge.
- Scream and Ground slam are still in the Gambit's pool.

## 1.5.15 (beta)
- **Rugrat: Item Throw** – grab a nearby valuable, use again to throw it really fast (real physics; 20–90 damage
  to hiders depending on speed and weight).
- Swarm: real Gnomes / Bangers are spawned first and then moved next to the monster (they appeared somewhere in the
  level before). Extra log lines show where they are.
- Swarm: the real Gnomes / Bangers now really spawn when "Disable normal enemies" is on.
- Flying (Oogly, Spewer, Flying Charge) uses your own jump / crouch keys from the game settings to go up / down.
- **Swarm** now spawns the game's real Gnomes / Bangers: they use the game's own vision and pathfinding (no more
  knowing where everyone is / walking through walls) and ignore the monster. Despawn after 30 s.
- Charge goes further (~14 m instead of ~8 m). Lunge unchanged.
- Clown laser: 50 damage per tick (was 25).
- F8 menu: **map size (level 1–20)** + **Load new map** button. New maps (button or map vote) are generated for that
  level – higher level = bigger map and higher moon phase. "Keep current" leaves the level as it is.
- F8 menu: **time recommendation by moon phase** (maps get bigger every phase) – moon 0: hide 30 s / hunt 3:00,
  +10 s / +1:00 per phase (max 75 s / 8:00). One click applies it.
- **After a round** (issue #4): surviving hiders are shown to everyone for 6 s, then every dead player is revived and
  healed and everyone is teleported into the truck. Then a **vote**: volunteer to be the next monster and vote to stay
  on the map or switch to one of 3 other maps. Can be turned off in the F8 menu (`Round / AfterRound`).
- **Charge** (Robe, Headgrab): short wind-up, then a fast horizontal dash – 60 damage on contact.
- **Lunge** (Headman, Chef): the same, but in the camera direction (also up/down and in the air).
- **Gnome and Banger are playable** – special **Swarm**: summons 5 allies that hunt hiders on their own for 30 s.
  Gnomes hit again and again (10 damage), Bangers blow themselves up (35 damage, 3 m).
- The monster can't open the map (Tab) during a round – an open map is closed when the round starts.
- Flying monsters stop below the ceiling, and the third-person camera no longer looks through ceilings/walls
  when you're pressed against them.
- **Flying Grab / Zero-G Grab:** caught hiders now tumble (ragdoll) and can't get up while the ability lasts,
  so the monster can grab and carry them. Flying Grab lasts 8 s (cooldown 20 s).
- **Heart Hugger: Noxious Gas** – spews 5 gas clouds (1.8 m radius) that drift out and linger for 10 s.
  Hiders inside are tranquilized: very slow, sluggish camera, pink haze. (Heart gas pull is now only a Gambit roll.)
- **Gambit** can roll every special in the mod (incl. Flying Charge, Flying Grab, Zero-G Grab, Noxious Gas) – new specials are added automatically.
- Radar Ping shows the hiders for 2 s instead of 1 s.

## 1.5.0
- **Damage instead of instant kills:** the main attack does 40 damage (players have 100 HP, config `AttackDamage`).
  Running into hiders no longer kills them. Specials do damage too: Laser 25 / 0.5 s, Shot 60, Leap 40, Throw 40.
- **Player Scan** (roar): shows how many players are within 15 m instead of the direction. Cooldown 20 s (`ScanCooldown`).
- **Radar Ping** (was X-ray): shows position and distance of every hider within 30 m for 1 s, 2 min cooldown. Every hider gets told
  whether they were detected or not.
- **Rapid Charge** (was Sprint): 5 s at 1.5x speed, 20 damage every 0.5 s to hiders close by, no main attack meanwhile.
- Test mode: no cooldowns.
- **Oogly: Flying Grab** – invisible stun bubble around it, and it can always fly. **Mentalist: Zero-G Grab** – stun bubble
  with zero gravity. **Spewer** can always fly too (space up, ctrl down).
- Cleanup Crew's head bounces off walls and explodes after 4 s (blinking faster and faster).
- Clown can't move while charging / firing the laser.
- Clown laser stays on the crosshair (jumping no longer knocks it off for the rest of the round).
- Oogly model tilted 45° more upright.
- Monster sounds no longer stack and play at most 2.5 s (Spewer's long puke sound).
- **Specials closer to the game:** Cleanup Crew throws its head (bomb + uranium cloud), Spewer pukes,
  Mentalist levitates and slams, Trudge ground-slams, Heart Hugger pulls hiders in with gas,
  Bowtie's scream pushes hiders away, Gambit rolls a random special.
- Apex Predator shows its attack form during Flying Charge. Rapid / Flying Charge have a visible aura.
- Fix: monster chosen during the hiding phase (e.g. Reaper, Elsa) was invisible / in the wrong form – hiding the own body
  no longer resets the monster's animation.
- Third-person camera no longer goes through the ceiling with tall monsters.
- Apex Predator: the monster-form meshes are shown during Flying Charge (and the duck grows).
- Softer effects: weaker colours, no flickering stun overlay, no spheres/sparks drawn around the camera
  (tight rooms, first person), charge aura is a ring on the floor.
- Big scan / radar waves are rings on the floor now (no more tinted screen). Oogly: stray trail parts hidden.
- **Flying Charge** (new, Apex Predator): fly for 6 s (space up, ctrl down), 10 damage every 0.5 s to hiders close by.

## 1.4.0
- **Every monster has a special ability** (middle mouse / F):
  Laser, Shot, Sprint, Leap attack, X-ray vision, Throw, Shockwave – see the README for who has what.
- Specials are visible everywhere: monster cards in both menus, ability bar with cooldowns for the monster,
  hiders see the monster's special while hiding and get a warning when it is used.
- **Echo roar:** roaring now shows the monster arrows towards every hider within 15 m for 1.5 s
  (direction only, no distance). Hiders it finds get an "Echoed!" warning.
- Monster models: animators are pushed into a visible state (big form, spawned, not despawning/stunned)
  and the model is re-grounded after transforming – fixes Elsa and similar two-form monsters.
- New full-screen **start menu (F8)**: seeker, monster and rules side by side, scores, big start button.

## 1.3.1
- New full-screen **monster selection**: card grid, details with the monster's abilities, countdown bar,
  "Random monster" button, keyboard control (arrows/WASD, Enter), reopen with **C** during the hiding phase.
- If the monster dies, the round now ends and the hiders win (scores are counted).
- "Monster invincible" now blocks every way the game can hurt or kill a player, not just one.
- Multiplayer: kills (touch, attack, laser) use the real network position of other players and
  horizontal distance – abilities should now hit other players, not only test dummies.
- More robust check that monster actions really come from the monster's player.
- Log shows distances for every attack (helps with tuning).

## 1.3.0
- **Score system** (totals over all rounds, shown after every round and in the F8 menu; host can reset):
  - Monster: 1 point per hider eaten.
  - Hiders: whoever lasts longest gets as many points as there were hiders, the next one 1 less, …,
    the first one eliminated gets 0. Everyone alive at the end gets the full points. Aborted rounds don't count.
- **Seeker picks their own monster** during the hiding phase (can be switched off in the F8 menu).
- **Clown laser:** laser monsters fire the game's real laser with the middle mouse button or **F**
  (3 s, 12 s cooldown). Everything the beam touches dies; walls and objects block it.
- **Monster can open doors again:** grabbing is allowed (doors, buttons, carts are grabbed in R.E.P.O.).
  Can be switched off with `Seeker / CanGrab`.

## 1.2.3
- Fix for R.E.P.O. v0.5.0: `PlayerController.OverrideSpeed` changed, which crashed the whole monster control
  every frame (no camera, attack, roar, speed or stamina). Game methods that can change between versions are
  now called version-tolerantly, and every monster feature runs separately.
- Harmony patches are applied one by one; a missing target only disables that one feature.
- Monster models are stripped in dependency order: no more "Can't remove … depends on it" errors in the log.

## 1.2.2
- Third-person camera now hooks into R.E.P.O.'s own camera render step (CameraUpdate) in addition to the render callbacks.
- Camera distance and height adapt to the size of the monster.
- Safety: if the third-person camera doesn't work, your own monster body is hidden so it never blocks your view.
- Roar plays through the game's own sound system; falls back to a generated growl if a monster has no sounds.
- Roar also on **R**, and shows a "ROAR!" banner.
- Test overlay shows camera status and the last played sound.

## 1.2.1
- Fix: third-person camera did nothing (R.E.P.O.'s camera is not Unity's `Camera.main`).
- Fix: monster controls were blocked by a wrong chat check.
- Fix: test keys (F9/F10/F11) now work independently of the monster controls.
- Seeker position for kills/dummies now taken from the player controller.
- One failing part no longer stops the rest of the mod; errors are shown in the test overlay and the log.
- More diagnostics in the test overlay and the log.

## 1.2.0
- **Test mode** for solo testing: start a round alone, you become the monster and training dummies act as hiders.
- Attack and touch kills work on the dummies; the overlay shows hit/miss with distance and angle.
- Test keys: F9 next monster (Shift+F9 previous), F10 spawn a dummy in front of you, F11 toggle overlay.
- Debug overlay and detailed log for each monster model (renderers, size, sounds, animator).

## 1.1.0
- The seeker now **is** a real R.E.P.O. monster: the model is taken from the game's enemies (choose one or random).
- Third-person camera for the monster so you see your own monster body (toggle with V).
- Monster abilities: **Attack** (left mouse, lunge + kill in front of you) and **Roar** (right mouse, plays the monster's sound, hiders nearby see a red flash).
- Monster sounds come from the original enemy.
- Monster can't grab objects.
- New settings: attack range, cooldowns, camera distance, key bindings.

## 1.0.0
- Initial release: Hide & Seek game mode with monster seeker.
